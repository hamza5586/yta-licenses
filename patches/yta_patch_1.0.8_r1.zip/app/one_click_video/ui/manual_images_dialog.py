"""Popup for the BunnyFlow manual mode: compact numbered cards (picture / clip preview + Copy prompt) and a progress summary."""
from __future__ import annotations

import subprocess
import tempfile
import threading
from pathlib import Path

from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QPixmap, QRegion
from PySide6.QtWidgets import (QApplication, QDialog, QFileDialog, QFrame, QGridLayout, QHBoxLayout, QLabel, QProgressBar, QPushButton,
                               QScrollArea, QVBoxLayout, QWidget)

from app.one_click_video.services import manual_images as MI

COLS = 3
THUMB_W, THUMB_H = 210, 118


class _Card(QFrame):
    def __init__(self, dlg, item, number: int):
        super().__init__()
        self.dlg, self.item, self.number = dlg, item, number
        self.setObjectName("card")
        self.setFixedWidth(THUMB_W + 24)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(10, 8, 10, 10)
        lay.setSpacing(6)
        self.title = QLabel(item.get("label") or f"#{number}")
        self.title.setStyleSheet("font-weight:800;font-size:15px;")
        lay.addWidget(self.title)
        self.pic = QLabel("waiting…")
        self.pic.setAlignment(Qt.AlignCenter)
        self.pic.setFixedSize(THUMB_W, THUMB_H)
        self.pic.setStyleSheet("background:#f0eefb;border-radius:8px;color:#888;")
        self.pic.setToolTip(item.get("prompt") or "")
        lay.addWidget(self.pic)
        self.btn = QPushButton("Copy prompt")
        self.btn.setCursor(Qt.PointingHandCursor)
        self.btn.clicked.connect(self._copy)
        self.undo = QPushButton("Undo")
        self.undo.setToolTip("The picture landed on the wrong scene: free it, then copy the right prompt again")
        self.undo.clicked.connect(self._undo)
        self.undo.hide()
        row = QHBoxLayout()
        row.setSpacing(6)
        row.addWidget(self.btn, 1)
        row.addWidget(self.undo)
        lay.addLayout(row)
        self._shown = ""
        self._frame = self._frame_of = self._frame_for = self._no_frame = ""

    def _copy(self):
        QApplication.clipboard().setText(self.item["prompt"] or "")
        self.dlg.sess.copy(self.item["sid"])
        self.refresh()

    def _undo(self):
        self.dlg.sess.undo(self.item["sid"], self.dlg.sess.store)
        self._shown = self._frame = self._frame_of = self._frame_for = self._no_frame = ""
        self.pic.clear()
        self.pic.setText("waiting…")
        self.refresh()

    def _grab(self, path):
        """A picture of the clip (first second) so the card shows what was downloaded."""
        try:
            from app.one_click_video.utils.audio import find_tool
            tool = find_tool("ffmpeg")
            out = Path(tempfile.gettempdir()) / f"yt_manual_{abs(hash(path))}.jpg"
            if tool:
                subprocess.run([tool, "-y", "-v", "error", "-ss", "0.5", "-i", path, "-frames:v", "1", "-vf", "scale=440:-2", str(out)],
                               capture_output=True, timeout=60, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            if out.is_file():
                self._frame, self._frame_of = str(out), path
                return
        except Exception:                                          # noqa: BLE001
            pass
        self._no_frame = path

    def _show(self, file):
        pm = QPixmap(file)
        if pm.isNull():
            return False
        self.pic.setPixmap(pm.scaled(self.pic.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation))
        return True

    def refresh(self):
        path = self.item["path"]
        self.undo.setVisible(bool(path))
        if path and path != self._shown:
            if self.dlg.sess.media != "video":
                if self._show(path):
                    self._shown = path
            elif self._frame and self._frame_of == path and Path(self._frame).is_file():
                if self._show(self._frame):
                    self._shown = path
            elif self._no_frame == path:
                self.pic.setText("🎬 clip received")
            elif self._frame_for != path:
                self._frame_for = path
                self.pic.setText("🎬 loading preview…")
                threading.Thread(target=self._grab, args=(path,), daemon=True).start()
        if path:
            self.btn.setText("✓ Received")
            self.btn.setEnabled(False)
        else:
            self.btn.setEnabled(True)
            if self.item.get("copied"):
                self.btn.setText("Copied ✓ · again")
                if not self._shown:
                    self.pic.setText("paste in Flow, then download…")
            else:
                self.btn.setText("Copy prompt")


class MiniNavigator(QWidget):
    """Small round always-on-top bubble in the screen's right corner: done/total count + 'Back' (previous prompt), 'Copy' (this
    prompt again) and 'Next' (next prompt without a picture). Works over Chrome so the user never has to come back to the software."""
    SIZE = 172

    def __init__(self, sess):
        super().__init__(None, Qt.Tool | Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint)
        self.sess, self.pos_i, self._drag = sess, 0, None
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setFixedSize(self.SIZE, self.SIZE)
        self.setStyleSheet("QLabel{color:white;background:transparent;}"
                           "QPushButton{background:rgba(255,255,255,0.16);color:white;border:1px solid rgba(255,255,255,0.28);"
                           "border-radius:13px;font-weight:700;font-size:11px;padding:0;}"
                           "QPushButton:hover{background:rgba(255,255,255,0.30);}"
                           "QPushButton#main{background:#2DD4A0;color:#0b2b22;border:0;}"
                           "QPushButton#main:hover{background:#5eead4;}")
        S = self.SIZE
        self.count = QLabel("0/0", self)
        self.count.setAlignment(Qt.AlignCenter)
        self.count.setStyleSheet("font-weight:800;font-size:30px;color:white;")
        self.count.setGeometry(0, 26, S, 42)
        self.now = QLabel("", self)
        self.now.setAlignment(Qt.AlignCenter)
        self.now.setStyleSheet("font-size:11px;color:#c7d2fe;")
        self.now.setGeometry(0, 68, S, 18)
        self.b_back = QPushButton("◀", self)
        self.b_back.setGeometry(18, 96, 36, 28)
        self.b_back.setToolTip("Previous prompt (copied)")
        self.b_copy = QPushButton("Copy", self)
        self.b_copy.setGeometry(58, 96, 56, 28)
        self.b_copy.setToolTip("Copy this prompt again")
        self.b_next = QPushButton("Next ▶", self)
        self.b_next.setObjectName("main")
        self.b_next.setGeometry(118, 96, 40, 28)
        self.b_next.setToolTip("Next prompt without a picture (copied)")
        self.b_next.setText("▶")
        self.b_back.clicked.connect(self._back)
        self.b_copy.clicked.connect(self._copy)
        self.b_next.clicked.connect(self._next)
        for i, it in enumerate(sess.items):
            if not it["path"]:
                self.pos_i = i
                break
        scr = QApplication.primaryScreen().availableGeometry()
        self.move(scr.right() - self.SIZE - 14, scr.top() + 90)
        self.t = QTimer(self)
        self.t.timeout.connect(self._refresh)
        self.t.start(600)
        self._refresh()

    def paintEvent(self, _e):
        from PySide6.QtCore import QRectF
        from PySide6.QtGui import QBrush, QColor, QLinearGradient, QPainter, QPen
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        r = QRectF(4, 4, self.SIZE - 8, self.SIZE - 8)
        g = QLinearGradient(0, 0, self.SIZE, self.SIZE)
        g.setColorAt(0, QColor("#4f46e5"))
        g.setColorAt(1, QColor("#0f766e"))
        p.setBrush(QBrush(g))
        p.setPen(QPen(QColor("#2DD4A0"), 3))
        p.drawEllipse(r)
        done, total = self.sess.counts()
        if total:                                               # progress ring
            p.setBrush(Qt.NoBrush)
            p.setPen(QPen(QColor("#ffffff"), 4, Qt.SolidLine, Qt.RoundCap))
            p.drawArc(QRectF(10, 10, self.SIZE - 20, self.SIZE - 20), 90 * 16, -int(360 * 16 * done / total))
        p.end()

    def _cur(self):
        it = self.sess.items
        return it[self.pos_i] if 0 <= self.pos_i < len(it) else None

    def _copy(self):
        it = self._cur()
        if it is None:
            return
        QApplication.clipboard().setText(it["prompt"] or "")
        self.sess.copy(it["sid"])
        self._refresh()

    def _back(self):
        n = len(self.sess.items)
        if n:
            self.pos_i = (self.pos_i - 1) % n
        self._copy()

    def _next(self):
        items = self.sess.items
        n = len(items)
        for k in range(1, n + 1):
            j = (self.pos_i + k) % n
            if not items[j]["path"]:
                self.pos_i = j
                break
        self._copy()

    def _refresh(self):
        done, total = self.sess.counts()
        self.count.setText(f"{done}/{total}")
        self.update()
        it = self._cur()
        if it is not None:
            self.now.setText(f"#{self.pos_i + 1}" + (" ✓" if it["path"] else (" copied" if it.get("copied") else "")))
        if done >= total:
            self.now.setText("all done")

    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton:
            self._drag = e.globalPosition().toPoint() - self.frameGeometry().topLeft()
        elif e.button() == Qt.RightButton:
            self.close()

    def mouseMoveEvent(self, e):
        if self._drag is not None and e.buttons() & Qt.LeftButton:
            self.move(e.globalPosition().toPoint() - self._drag)

    def mouseReleaseEvent(self, _e):
        self._drag = None


class ManualImagesDialog(QDialog):
    def __init__(self, sess, parent=None):
        super().__init__(parent)
        self.sess = sess
        self.setWindowTitle("BunnyFlow — copy each prompt into Flow, then download")
        self.resize(760, 640)
        root = QVBoxLayout(self)
        self.head = QLabel("")
        self.head.setStyleSheet("font-weight:800;font-size:16px;")
        self.sub = QLabel("")
        self.sub.setStyleSheet("color:#555;")
        self.bar = QProgressBar()
        self.bar.setTextVisible(False)
        self.bar.setFixedHeight(10)
        root.addWidget(self.head)
        root.addWidget(self.sub)
        root.addWidget(self.bar)
        bulk = QHBoxLayout()
        self.copy_all = QPushButton("📋 Copy all prompts")
        self.copy_all.setToolTip("Copies every prompt that has no picture yet, one per line, in scene order")
        self.copy_all.clicked.connect(self._copy_all)
        self.save_txt = QPushButton("⬇ Download prompts (.txt)")
        self.save_txt.setToolTip("Saves every prompt in one text file, one per line")
        self.save_txt.clicked.connect(self._save_txt)
        bulk.addWidget(self.copy_all)
        bulk.addWidget(self.save_txt)
        self.chrome_btn = QPushButton("🌐 Open Chrome")
        self.chrome_btn.setToolTip("Opens (or brings back) the Chrome profile used for Flow")
        self.chrome_btn.clicked.connect(self._open_chrome)
        bulk.addWidget(self.chrome_btn)
        self.nav_btn = QPushButton("🧭 Open navigator")
        self.nav_btn.setToolTip("A small round bubble over Chrome: count + Copy / Next, so you never have to come back here")
        self.nav_btn.clicked.connect(self._open_nav)
        bulk.addWidget(self.nav_btn)
        profs = getattr(sess, "profiles", None) or []
        self.prof_box = None
        if len(profs) > 1:
            from PySide6.QtWidgets import QComboBox
            self.prof_box = QComboBox()
            self.prof_box.setToolTip("Switch the Chrome profile used for Flow. The picked profile opens and its download folder is watched.")
            self.prof_box.addItem("Switch profile…", None)
            for pid, label in profs:
                self.prof_box.addItem(label, pid)
            self.prof_box.activated.connect(self._switch_profile)
            bulk.addWidget(self.prof_box)
        bulk.addStretch(1)
        root.addLayout(bulk)
        row = QHBoxLayout()
        self.folder = QLabel("")
        self.folder.setStyleSheet("color:#777;font-size:11px;")
        change = QPushButton("Download folder…")
        change.clicked.connect(self._change)
        hide = QPushButton("Hide")
        hide.clicked.connect(self.hide)
        row.addWidget(self.folder, 1)
        row.addWidget(change)
        row.addWidget(hide)
        root.addLayout(row)
        sc = QScrollArea()
        sc.setWidgetResizable(True)
        sc.setFrameShape(QFrame.NoFrame)
        host = QWidget()
        grid = QGridLayout(host)
        grid.setSpacing(12)
        self.cards = [_Card(self, it, i + 1) for i, it in enumerate(sess.items)]
        for i, c in enumerate(self.cards):
            grid.addWidget(c, i // COLS, i % COLS, Qt.AlignTop)
        grid.setRowStretch(len(self.cards) // COLS + 1, 1)
        sc.setWidget(host)
        root.addWidget(sc, 1)
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.refresh)
        self.timer.start(700)
        self.refresh()

    def _open_nav(self):
        nav = getattr(self, "nav", None)
        if nav is None or not nav.isVisible():
            self.nav = MiniNavigator(self.sess)
        self.nav.show()
        self.nav.raise_()

    def done(self, r):
        nav = getattr(self, "nav", None)
        if nav is not None:
            nav.close()
        super().done(r)

    def _switch_profile(self, _i):
        pid = self.prof_box.currentData()
        if pid is None:
            return
        self.sess.cur_pid = pid
        self.prof_box.setCurrentIndex(0)
        self._open_chrome()

    def _open_chrome(self):
        fn = getattr(self.sess, "open_chrome", None)
        if fn is None:
            return
        self.chrome_btn.setEnabled(False)
        self.chrome_btn.setText("Opening…")

        def work():
            try:
                fn()
            finally:
                self._chrome_done = True
        self._chrome_done = False
        threading.Thread(target=work, daemon=True).start()

    @staticmethod
    def _line(text):
        return " ".join((text or "").split())

    def _copy_all(self):
        todo = [i for i in self.sess.items if not i["path"]]
        if not todo:
            return
        QApplication.clipboard().setText("\n".join(self._line(i["prompt"]) for i in todo))
        for i in todo:                                   # copied in scene order: the downloads are matched to them in the same order
            self.sess.copy(i["sid"])
        for c in self.cards:
            c.refresh()
        self.copy_all.setText(f"✓ {len(todo)} prompts copied")
        QTimer.singleShot(2500, lambda: self.copy_all.setText("📋 Copy all prompts"))

    def _save_txt(self):
        default = str(Path(self.sess.images_dir).parent / "prompts.txt")
        path, _ = QFileDialog.getSaveFileName(self, "Save all prompts", default, "Text file (*.txt)")
        if not path:
            return
        try:
            Path(path).write_text("\n".join(self._line(i["prompt"]) for i in self.sess.items) + "\n", encoding="utf-8")
            self.save_txt.setText("✓ Saved")
        except OSError as e:
            self.save_txt.setText(f"✖ {e}")
        QTimer.singleShot(2500, lambda: self.save_txt.setText("⬇ Download prompts (.txt)"))

    def _change(self):
        d = QFileDialog.getExistingDirectory(self, "Folder where Chrome saves downloads", str(self.sess.dl_dirs[0] if self.sess.dl_dirs else ""))
        if d:
            self.sess.set_dl_dir(d)
            if getattr(self, "on_dir", None):
                self.on_dir(d)

    def _current(self):
        """The card the user is on now: the first copied prompt still waiting, else the first one without a picture."""
        with self.sess.lock:
            for sid in self.sess.pending:
                it = self.sess._item(sid)
                if it and not it["path"]:
                    return it
            return next((i for i in self.sess.items if not i["path"]), None)

    def refresh(self):
        done, total = self.sess.counts()
        what = "clips" if self.sess.media == "video" else "pictures"
        cur = self._current()
        if cur is not None:
            n = (cur.get("label") or f"#{self.sess.items.index(cur) + 1}")
            self.head.setText(f"Now: {n}   ·   {done} of {total} {what} done")
        else:
            self.head.setText(f"All {total} {what} received ✓")
        self.sub.setText(f"{total - done} left   ·   {self.sess.seen_note}" + (f"   ·   {self.sess.chrome_msg}" if self.sess.chrome_msg else ""))
        if getattr(self, "_chrome_done", False):
            self._chrome_done = False
            self.chrome_btn.setEnabled(True)
            self.chrome_btn.setText("🌐 Open Chrome")
        self.bar.setMaximum(max(total, 1))
        self.bar.setValue(done)
        self.folder.setText(f"Watching: {self.sess.dl_dir}")
        for c in self.cards:
            c.refresh()
        if self.sess.finished or MI.get(self.sess.vid) is not self.sess or done >= total:
            self.timer.stop()
            QTimer.singleShot(1200, self.accept)           # all are in: close, the next step starts by itself
