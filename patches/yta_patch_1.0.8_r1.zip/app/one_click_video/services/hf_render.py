"""Pro editing engine: scenes are rendered by HyperFrames (HTML + GSAP, drawn by headless Chrome, encoded by FFmpeg) instead of
the plain FFmpeg zoom. The chosen pictures get a keyframed camera (several moves per scene, a punch on every cut, a vignette)
and come back as ordinary scene segments, so the existing transitions, grade, captions and mix keep working unchanged.

Everything here is best effort: when Node.js is missing, the render fails or the user cancels, the caller falls back to the
classic FFmpeg segments. HyperFrames is Apache-2.0 (https://github.com/heygen-com/hyperframes)."""
from __future__ import annotations

import json
import math
import os
import re
import shutil
import subprocess
import time
from pathlib import Path

HF_VERSION = "0.9.83"                      # pinned: a newer release can never change what clients get
GSAP_URL = "https://cdn.jsdelivr.net/npm/gsap@3.15.0/dist/gsap.min.js"
MIN_NODE = 22
NODE_VERSION = "22.12.0"                   # downloaded by the software itself when this PC has no Node.js (portable, no installer, no admin)
NODE_DOWNLOAD_URL = f"https://nodejs.org/dist/v{NODE_VERSION}/node-v{NODE_VERSION}-win-x64.zip"
node_state = {"state": "", "msg": "", "done": 0, "total": 0}          # "", "downloading", "done", "failed"
_node_lock = __import__("threading").Lock()


def node_dir() -> Path:
    from app.core import paths
    return paths.root_dir() / "node"


class HFError(RuntimeError):
    pass


def _extra_node_dirs() -> list[Path]:
    """Places where a portable / unzipped Node.js is usually left: Downloads (also one folder deeper), Desktop, C:\\Program Files\\nodejs."""
    out: list[Path] = []
    home = Path.home()
    for base in (home / "Downloads", home / "Desktop", home / "Documents"):
        try:
            if not base.is_dir():
                continue
            for c in sorted(base.glob("node*"), reverse=True):
                if c.is_dir():
                    out.append(c)
                    out += [x for x in sorted(c.glob("node*"), reverse=True) if x.is_dir()]
        except OSError:
            pass
    for pf in (os.environ.get("ProgramFiles"), os.environ.get("ProgramFiles(x86)")):
        if pf:
            out.append(Path(pf) / "nodejs")
    return out


def _prepend_path(d: Path) -> None:
    """npx needs node.exe on PATH of this process too."""
    cur = os.environ.get("PATH", "")
    if str(d) not in cur.split(os.pathsep):
        os.environ["PATH"] = str(d) + os.pathsep + cur


def find_node() -> tuple[str | None, str | None, str]:
    """(node path, npx path, message). The message is '' when Node.js 22+ and npx are found."""
    node, npx = shutil.which("node"), shutil.which("npx")
    if not node or not npx:
        d = node_dir()
        if (d / "node.exe").is_file() and (d / "npx.cmd").is_file():            # the copy this software downloaded
            node, npx = str(d / "node.exe"), str(d / "npx.cmd")
    if not node or not npx:
        for d in _extra_node_dirs():                                           # an unzipped Node.js the user keeps in Downloads etc.
            if (d / "node.exe").is_file() and (d / "npx.cmd").is_file():
                node, npx = str(d / "node.exe"), str(d / "npx.cmd")
                _prepend_path(d)
                break
    if not node or not npx:
        return None, None, "Node.js 22 or newer is needed for the Pro engine (install it from nodejs.org, then restart the app)."
    try:
        out = subprocess.run([node, "-v"], capture_output=True, text=True, timeout=20).stdout.strip()
        major = int(re.match(r"v(\d+)", out).group(1))
    except Exception:                                    # noqa: BLE001
        return None, None, "Node.js was found but its version could not be read."
    if major < MIN_NODE:
        return None, None, f"Node.js {major} is too old for the Pro engine: install Node.js {MIN_NODE} or newer (nodejs.org)."
    return node, npx, ""


def ensure_node(log=lambda m: None) -> bool:
    """Windows: download portable Node.js once into the software's own folder. Only one download runs at a time."""
    if not find_node()[2]:
        return True
    import sys
    if sys.platform != "win32" or not _node_lock.acquire(blocking=False):
        return False
    try:
        import tempfile
        import urllib.request
        import zipfile
        from app.licensing import tls
        node_state.update(state="downloading", msg="", done=0, total=0)
        log("Node.js not found: downloading it once (about 30 MB)")
        tmp = Path(tempfile.mkdtemp(prefix="yta_node_")) / "node.zip"
        req = urllib.request.Request(NODE_DOWNLOAD_URL, headers={"User-Agent": "YT-Automater"})
        with tls.urlopen(req, timeout=60) as r, open(tmp, "wb") as f:
            total = int(r.headers.get("Content-Length") or 0)
            done = 0
            while True:
                chunk = r.read(1 << 20)
                if not chunk:
                    break
                f.write(chunk)
                done += len(chunk)
                node_state.update(done=done, total=total)
        dest = node_dir()
        if dest.exists():
            shutil.rmtree(dest, ignore_errors=True)
        dest.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(tmp) as z:                                   # the zip has one top folder (node-v22...-win-x64): drop it
            for n in z.namelist():
                rel = n.split("/", 1)[1] if "/" in n else ""
                if not rel or n.endswith("/"):
                    continue
                target = (dest / rel).resolve()
                if dest.resolve() not in target.parents:
                    continue
                target.parent.mkdir(parents=True, exist_ok=True)
                with z.open(n) as src, open(target, "wb") as out:
                    shutil.copyfileobj(src, out)
        shutil.rmtree(tmp.parent, ignore_errors=True)
        ok = not find_node()[2]
        node_state.update(state="done" if ok else "failed", msg="" if ok else "Node.js could not be started after the download.")
        log("Node.js ready" if ok else "Node.js download finished but node could not run")
        return ok
    except Exception as e:                                                # noqa: BLE001
        node_state.update(state="failed", msg=str(e)[:160])
        log(f"Node.js download failed: {e}")
        return False
    finally:
        _node_lock.release()


def start_node_download(log=lambda m: None) -> None:
    import threading
    if node_state["state"] != "downloading" and find_node()[2]:
        threading.Thread(target=ensure_node, args=(log,), daemon=True, name="node-download").start()


# ---------------------------------------------------------------- camera
_PATTERNS = ("push_in", "pull_out", "pan_right", "pan_left", "rise", "push_corner")


def _safe(x: float, scale: float, size: float, margin: float = 0.82) -> float:
    """Largest sideways shift that still keeps the picture covering the frame at this scale (with room for a small rotation)."""
    limit = max((scale - 1.0) * size / 2.0 * margin - size * 0.012, 0.0)
    return max(-limit, min(limit, x))


def camera_keys(index: int, w: int, h: int) -> dict:
    """Deterministic camera plan for scene `index`: three key poses (scale, x, y, rotation) + the punch scale at the cut."""
    p = _PATTERNS[index % len(_PATTERNS)]
    sgn = 1 if (index // len(_PATTERNS)) % 2 == 0 else -1
    if p == "push_in":
        poses = [(1.10, 0, 0, 0), (1.20, 0.35 * sgn, -0.20, 0.3 * sgn), (1.30, 0.55 * sgn, -0.35, 0.0)]
    elif p == "pull_out":
        poses = [(1.32, 0.5 * sgn, 0.3, 0.0), (1.22, 0.2 * sgn, 0.1, -0.3 * sgn), (1.10, 0, 0, 0)]
    elif p == "pan_right":
        poses = [(1.20, -0.8, 0.1, 0), (1.22, 0.0, -0.1, 0.4), (1.24, 0.8, 0.1, 0)]
    elif p == "pan_left":
        poses = [(1.20, 0.8, -0.1, 0), (1.22, 0.0, 0.1, -0.4), (1.24, -0.8, -0.1, 0)]
    elif p == "rise":
        poses = [(1.22, 0.0, 0.8, 0), (1.24, 0.1 * sgn, 0.0, 0.3 * sgn), (1.26, 0.0, -0.8, 0)]
    else:
        poses = [(1.12, -0.6 * sgn, 0.5, 0), (1.22, 0.0, 0.0, 0.4 * sgn), (1.32, 0.7 * sgn, -0.5, 0)]
    out = []
    for s, fx, fy, rot in poses:                         # fx/fy are fractions (-1..1) of the free room at that scale
        free_x, free_y = max((s - 1.0) * w / 2.0 * 0.82 - w * 0.012, 0), max((s - 1.0) * h / 2.0 * 0.82 - h * 0.012, 0)
        out.append({"scale": round(s, 4), "x": round(_safe(fx * free_x, s, w), 1), "y": round(_safe(fy * free_y, s, h), 1),
                    "rotation": rot})
    return {"pattern": p, "poses": out, "punch": 0.07}


def build_html(items: list[dict], w: int, h: int) -> tuple[str, float]:
    """items: [{'file': 'img_0.jpg', 'length': seconds}] (back to back). Returns (html, total seconds)."""
    t, clips, js = 0.0, [], []
    for k, it in enumerate(items):
        L = max(float(it["length"]), 0.2)
        cam = camera_keys(it.get("seed", k), w, h)
        pose = cam["poses"]
        tid = f"p{k}"
        clips.append(f'<img id="{tid}" class="clip pic" src="{it["file"]}" data-start="{t:.3f}" data-duration="{L:.3f}" '
                     f'data-track-index="{k % 2}"/>')
        a, b, c = pose
        seg1, seg2 = L * 0.55, L * 0.45
        js.append(
            f'tl.fromTo("#{tid}",{{scale:{a["scale"] + cam["punch"]},x:{a["x"]},y:{a["y"]},rotation:{a["rotation"]}}},'
            f'{{scale:{a["scale"]},duration:{min(0.45, L * 0.2):.3f},ease:"power3.out"}},{t:.3f});'
            f'tl.to("#{tid}",{{scale:{b["scale"]},x:{b["x"]},y:{b["y"]},rotation:{b["rotation"]},duration:{seg1:.3f},ease:"sine.inOut"}},{t:.3f});'
            f'tl.to("#{tid}",{{scale:{c["scale"]},x:{c["x"]},y:{c["y"]},rotation:{c["rotation"]},duration:{seg2:.3f},ease:"sine.inOut"}},{t + seg1:.3f});')
        t += L
    css = (f"html,body{{margin:0;width:{w}px;height:{h}px;overflow:hidden;background:#000}}"
           f"#root{{position:relative;width:{w}px;height:{h}px;overflow:hidden}}"
           f".pic{{position:absolute;left:0;top:0;width:{w}px;height:{h}px;object-fit:cover;transform-origin:50% 50%}}"
           f".vig{{position:absolute;inset:0;background:radial-gradient(ellipse at center,rgba(0,0,0,0) 58%,rgba(0,0,0,.42) 100%)}}")
    html = (f'<!doctype html><html><head><meta charset="UTF-8"/><meta name="viewport" content="width={w}, height={h}"/>'
            f'<script src="{GSAP_URL}"></script><style>{css}</style></head><body>'
            f'<div id="root" data-composition-id="main" data-start="0" data-duration="{t:.3f}" data-width="{w}" data-height="{h}">'
            + "".join(clips) +
            f'<div class="clip vig" data-start="0" data-duration="{t:.3f}" data-track-index="2"></div></div>'
            '<script>const tl=gsap.timeline({paused:true});' + "".join(js) +
            'window.__timelines["main"]=tl;tl.seek(0);</script></body></html>')
    return html, t


# ---------------------------------------------------------------- render
def _run_ff(ffmpeg: str, args: list[str], timeout: int = 900) -> None:
    r = subprocess.run([ffmpeg, "-y", "-v", "error", *args], capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=timeout)
    if r.returncode != 0:
        raise HFError((r.stderr or "ffmpeg failed").strip()[-300:])


def _project_files(work: Path) -> None:
    (work / "hyperframes.json").write_text(json.dumps({"paths": {"blocks": "compositions", "components": "compositions/components",
                                                                 "assets": "assets"}, "media": {"autoProxy": True}}), encoding="utf-8")
    (work / "meta.json").write_text(json.dumps({"id": "scene-pack", "name": "scene-pack"}), encoding="utf-8")


def render_scenes(items: list[dict], w: int, h: int, fps: int, workdir: Path, ffmpeg: str, progress=None, cancelled=None,
                  popen=subprocess.Popen, timeout_per_second: float = 12.0) -> dict[int, Path]:
    """items: [{'idx': scene index, 'image': Path, 'length': seconds}] -> {idx: segment mp4 of exactly that length (video only)}.
    All pictures go into ONE composition (one browser start-up), then the result is cut into the scene segments."""
    node, npx, msg = find_node()
    if msg:
        raise HFError(msg)
    work = Path(workdir)
    if work.exists():
        shutil.rmtree(work, ignore_errors=True)
    work.mkdir(parents=True, exist_ok=True)
    _project_files(work)
    comp_items = []
    for k, it in enumerate(items):
        name = f"img_{k}.jpg"
        _run_ff(ffmpeg, ["-i", str(it["image"]), "-vf", "scale='min(2560,iw)':'min(2560,ih)':force_original_aspect_ratio=decrease",
                         "-frames:v", "1", "-q:v", "2", str(work / name)])
        comp_items.append({"file": name, "length": it["length"], "seed": it.get("seed", it["idx"])})
    html, total = build_html(comp_items, w, h)
    (work / "index.html").write_text(html, encoding="utf-8")
    out = work / "pro_scenes.mp4"
    env = dict(os.environ, DO_NOT_TRACK="1", HYPERFRAMES_NO_TELEMETRY="1", NO_UPDATE_NOTIFIER="1")
    env["PATH"] = str(Path(node).parent) + os.pathsep + env.get("PATH", "")        # npx finds the node next to it (also the downloaded one)
    base = [npx, "--yes", f"hyperframes@{HF_VERSION}"]
    try:                                              # clients' PCs never send usage data
        subprocess.run([*base, "telemetry", "disable"], cwd=work, env=env, capture_output=True, timeout=180)
    except Exception:                                  # noqa: BLE001
        pass
    cmd = [*base, "render", "--fps", str(int(fps)), "-o", str(out), "--no-wait"]
    deadline = time.time() + max(300.0, total * timeout_per_second)
    p = popen(cmd, cwd=work, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, encoding="utf-8", errors="replace")
    tail: list[str] = []
    try:
        for line in p.stdout:
            tail = (tail + [line.rstrip()])[-12:]
            if line.startswith("@hf-progress"):
                try:
                    pct = float(json.loads(line.split(" ", 1)[1]).get("pct", 0))
                    if progress:
                        progress(f"Pro engine: drawing frames {pct:.0f}%", int(pct), 100)
                except (ValueError, IndexError):
                    pass
            if cancelled and cancelled():
                p.kill()
                raise HFError("Cancelled.")
            if time.time() > deadline:
                p.kill()
                raise HFError("The Pro engine took too long and was stopped.")
        p.wait(timeout=60)
    finally:
        if p.poll() is None:
            p.kill()
    if p.returncode != 0 or not out.is_file():
        raise HFError("Pro engine failed: " + " | ".join(x for x in tail if x)[-300:])
    segs, t = {}, 0.0
    for it in items:
        seg = work / f"seg_{it['idx']:04d}.mp4"
        _run_ff(ffmpeg, ["-ss", f"{t:.3f}", "-i", str(out), "-t", f"{it['length']:.3f}", "-an", "-c:v", "libx264", "-preset", "veryfast",
                         "-crf", "14", "-pix_fmt", "yuv420p", "-r", str(int(fps)), str(seg)])
        segs[it["idx"]] = seg
        t += float(it["length"])
    return segs


def choose_scenes(durations: list[float], texts: list[str], is_image: list[bool], scope: str, hook_seconds: float = 45.0,
                  max_seconds: float = 240.0) -> list[int]:
    """Which scenes go to the Pro engine. scope: 'off' | 'hook' (first seconds + scenes with numbers/years) | 'all'.
    Only still pictures qualify (video clips already move), and the total stays within max_seconds so render time stays sane."""
    if scope not in ("hook", "all"):
        return []
    picks, used, start = [], 0.0, 0.0
    for i, d in enumerate(durations):
        want = is_image[i]
        if scope == "hook":
            highlight = bool(re.search(r"\d", texts[i] or ""))
            want = want and (start < hook_seconds or highlight)
        if want and used + d <= max_seconds:
            picks.append(i)
            used += d
        start += d
    return picks
