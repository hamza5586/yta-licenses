"""BunnyFlow manual picture mode: the app only opens the BunnyFlow Chrome profile (no script runs on the page). A popup shows one
card per scene with a Copy-prompt button; the user pastes the prompt in Flow and downloads the picture. The app watches the
download folder, gives each new picture to the scene whose prompt was copied (first copied = first downloaded) and shows it live."""
from __future__ import annotations

import shutil
import threading
import time
from pathlib import Path

IMAGE_EXT = {".png", ".jpg", ".jpeg", ".webp"}
VIDEO_EXT = {".mp4", ".mov", ".webm", ".mkv"}
SETTLE = 2.0
_SESSIONS: dict[int, "ManualSession"] = {}


class ManualSession:
    def __init__(self, vid: int, items: list[dict], dl_dir: Path, images_dir: Path, media: str = "image"):
        self.media = media
        self.exts = VIDEO_EXT if media == "video" else IMAGE_EXT
        self.vid, self.items, self.images_dir = vid, items, Path(images_dir)
        self.dl_dirs = [Path(d) for d in (dl_dir if isinstance(dl_dir, (list, tuple)) else [dl_dir])]
        self.start_ts = time.time() - 45.0       # a picture downloaded just before the popup opened still counts
        self.lock = threading.Lock()
        self.pending: list[int] = []          # scene ids in the order their prompt was copied (waiting for a picture)
        self.finished = False
        self.profile_dir = None
        self.open_chrome = None
        self.chrome_msg = ""
        self._hist_at = 0.0
        self._hist_files: list[str] = []
        self.seen_note = ""
        self.taken: set[str] = set()
        self.message = ""

    # ---- UI side
    def copy(self, sid: int) -> None:
        with self.lock:
            it = self._item(sid)
            if it is None or it["path"]:
                return
            if sid in self.pending:
                self.pending.remove(sid)
            self.pending.append(sid)
            it["copied"] = True

    waiting_files = 0

    ai = None                                   # (gemini key, model): lets the app LOOK at the picture and pick its prompt

    def _ai_match(self, p: Path, cands: list[dict]):
        """Gemini looks at the downloaded picture and says which of the waiting prompts it shows. Only a confident answer counts;
        any problem (no key, offline, unsure) returns None and the normal order is used. Called WITHOUT the lock."""
        if not self.ai or self.media != "image" or len(cands) < 2:
            return None
        try:
            import base64, io, json
            from app.one_click_video.providers import http
            key, model = self.ai
            raw = Path(p).read_bytes()
            try:
                from PIL import Image
                im = Image.open(io.BytesIO(raw)).convert("RGB")
                im.thumbnail((640, 640))
                buf = io.BytesIO()
                im.save(buf, "JPEG", quality=80)
                raw = buf.getvalue()
            except Exception:                                    # noqa: BLE001
                pass
            lines = "\n".join(f"{n}. {(c['prompt'] or '')[:220]}" for n, c in enumerate(cands, 1))
            payload = {"systemInstruction": {"parts": [{"text": "You match one picture to the prompt it was made from. Reply JSON "
                       "{\"number\": int, \"confidence\": int}: number = the prompt that this picture shows best (0 if none fits), "
                       "confidence 1-10. Compare subject, place, objects, action, mood."}]},
                       "contents": [{"role": "user", "parts": [{"text": "PROMPTS:\n" + lines},
                                                                 {"inlineData": {"mimeType": "image/jpeg", "data": base64.b64encode(raw).decode()}}]}],
                       "generationConfig": {"responseMimeType": "application/json", "temperature": 0.0,
                                            "responseSchema": {"type": "OBJECT", "properties": {"number": {"type": "INTEGER"},
                                                               "confidence": {"type": "INTEGER"}}, "required": ["number", "confidence"]}}}
            res = http.json_request("POST", f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent", payload,
                                    headers={"x-goog-api-key": key}, timeout=30.0, retries=1)
            out = json.loads(res["candidates"][0]["content"]["parts"][0]["text"])
            n, conf = int(out.get("number", 0)), int(out.get("confidence", 0))
            if 1 <= n <= len(cands) and conf >= 7:
                return cands[n - 1]["sid"]
        except Exception:                                        # noqa: BLE001
            return None
        return None

    def _match_sid(self, p: Path):
        """Scene whose prompt best fits the words of the downloaded file's name (Flow names a picture after what it shows).
        Only a clear winner counts; otherwise None and the copy order decides. Call with the lock held."""
        import re
        stem = re.sub(r"[_\s-][0-9a-f]{6,10}$", "", p.stem.lower().replace("\u2026", " "))
        words = [w for w in re.findall(r"[^\W_]+", stem) if len(w) >= 4 and not w.isdigit()]
        if len(words) < 2:
            return None
        scored = []
        for it in self.items:
            if it["path"]:
                continue
            pw = set(re.findall(r"[^\W_]+", (it["prompt"] or "").lower()))
            p5 = {x[:5] for x in pw}
            hit = sum(1 for w in words if w in pw or w[:5] in p5)
            scored.append((hit, it["sid"]))
        scored.sort(reverse=True)
        if not scored:
            return None
        best = scored[0]
        second = scored[1][0] if len(scored) > 1 else 0
        if best[0] >= 3 and best[0] / len(words) >= 0.75 and best[0] >= second + 2:
            return best[1]
        return None

    def undo(self, sid: int, store) -> None:
        """The picture landed on the wrong scene: free the scene and put the file back in the pool (copy the right prompt again)."""
        with self.lock:
            it = self._item(sid)
            if it is None or not it["path"]:
                return
            try:
                Path(it["path"]).unlink()
            except OSError:
                pass
            self.taken.discard(it.get("src", ""))
            it["path"], it["src"], it["copied"], it["hash"] = "", "", False, ""
            if sid in self.pending:
                self.pending.remove(sid)
        if sid > 0:
            store.update_scene(sid, status="Pending", clip_path="", error="")

    def _item(self, sid):
        return next((i for i in self.items if i["sid"] == sid), None)

    def counts(self) -> tuple[int, int]:
        with self.lock:
            return sum(1 for i in self.items if i["path"]), len(self.items)

    def _ext(self, p: Path):
        """The file's real type: its extension, or (Flow saves pictures with a bare id as name, no extension) its first bytes."""
        suf = p.suffix.lower()
        if suf in self.exts:
            return suf
        if suf not in ("", ) and not (len(suf) > 6):
            if suf in (".crdownload", ".tmp", ".part") or suf in IMAGE_EXT | VIDEO_EXT:
                return None
        try:
            with open(p, "rb") as f:
                head = f.read(16)
        except OSError:
            return None
        if self.media == "video":
            return ".mp4" if head[4:8] == b"ftyp" else (".webm" if head[:4] == b"\x1aE\xdf\xa3" else None)
        if head[:8] == b"\x89PNG\r\n\x1a\n":
            return ".png"
        if head[:3] == b"\xff\xd8\xff":
            return ".jpg"
        if head[:4] == b"RIFF" and head[8:12] == b"WEBP":
            return ".webp"
        return None

    @property
    def dl_dir(self):
        return " | ".join(str(d) for d in self.dl_dirs)

    def set_dl_dir(self, d: str) -> None:
        with self.lock:
            self.dl_dirs = [Path(d)] + [x for x in self.dl_dirs if str(x) != str(d)]

    # ---- worker side
    def scan(self, store) -> int:
        """Takes new finished pictures from the download folder; returns how many scenes got one."""
        with self.lock:
            dirs, start = list(self.dl_dirs), self.start_ts
        found = []
        now = time.time()
        files = []
        if time.time() - self._hist_at > 4:                 # Chrome's own download history knows the exact file, wherever it was saved
            self._hist_at = time.time()
            self._hist_files = history_files(self.profile_dir, start)
        files += [Path(x) for x in self._hist_files]
        for d in dirs:
            try:
                files += list(d.iterdir()) if d.is_dir() else []
            except OSError:
                continue
        for p in files:
            try:
                if not p.is_file() or p.name.startswith(".") or str(p) in self.taken:
                    continue
                st = p.stat()
                if st.st_size < (20000 if self.media == "video" else 1024) or st.st_mtime < start or now - st.st_mtime < SETTLE:
                    continue
                if self._ext(p) is None:
                    continue
                found.append((st.st_mtime, p))
            except OSError:
                continue
        self.seen_note = (f"{len(found)} new file(s) seen" if found else "no new file seen yet") + \
                         (f"; {len(self.pending)} prompt(s) copied and waiting" if self.pending else "; copy a prompt first")
        got = 0
        if found:
            for i in self.items:                          # pictures received before this popup opened have no fingerprint yet
                if i["path"] and not i.get("hash"):
                    i["hash"] = _digest(Path(i["path"]))
        for _, p in sorted(set(found)):
            h = _digest(p)
            with self.lock:
                if h and any(i.get("hash") == h for i in self.items if i["path"]):
                    self.taken.add(str(p))               # the same picture downloaded twice: never given to a second scene
                    continue
            with self.lock:
                # the 1st picture downloaded goes to scene 1, the 2nd to scene 2, the 3rd to scene 3 ...: the next scene (in number order)
                # that has no picture yet. Nothing else decides: not the copy order, not the file name.
                sid = next((i["sid"] for i in self.items if not i["path"]), None)
                if sid is None:
                    break                       # nothing copied is waiting: the file waits too (never guessed, no mix-ups)
                it = self._item(sid)
            self.images_dir.mkdir(parents=True, exist_ok=True)
            target = self.images_dir / f"{it.get('stem') or 'Scene_%03d' % (it['idx'] + 1)}{self._ext(p)}"
            try:
                shutil.copy2(p, target)
            except OSError:
                continue
            if sid > 0:
                store.update_scene(sid, status="Completed", clip_path=str(target), error="")
            with self.lock:
                it["path"] = str(target)
                it["src"] = str(p)
                it["hash"] = h
                self.taken.add(str(p))
                if sid in self.pending:
                    self.pending.remove(sid)
            got += 1
        return got


def start(vid, items, dl_dir, images_dir, media="image") -> ManualSession:
    s = ManualSession(vid, items, dl_dir, images_dir, media)
    _SESSIONS[vid] = s
    return s


def get(vid):
    return _SESSIONS.get(vid)


def active() -> list[ManualSession]:
    return [s for s in _SESSIONS.values() if not s.finished]


def end(vid) -> None:
    s = _SESSIONS.pop(vid, None)
    if s:
        s.finished = True


def chrome_download_dirs(profile_dir, extra=()) -> list[Path]:
    """Where the profile's Chrome saves downloads: its own setting (Preferences file), then the normal Downloads folder."""
    import json
    out: list[Path] = [Path(x) for x in extra if x]
    if profile_dir:
        for pref in (Path(profile_dir) / "Default" / "Preferences", Path(profile_dir) / "Preferences"):
            try:
                data = json.loads(pref.read_text(encoding="utf-8"))
            except Exception:                                    # noqa: BLE001
                continue
            for d in ((data.get("download") or {}).get("default_directory"), (data.get("savefile") or {}).get("default_directory")):
                if d:
                    out.append(Path(d))
    out.append(Path.home() / "Downloads")
    seen, res = set(), []
    for d in out:
        if str(d).lower() not in seen:
            seen.add(str(d).lower())
            res.append(d)
    return res


def history_files(profile_dir, since_ts: float) -> list[str]:
    """Files Chrome finished downloading since since_ts (from the profile's History database; read from a copy)."""
    import shutil as _sh, sqlite3, tempfile
    if not profile_dir:
        return []
    for hist in (Path(profile_dir) / "Default" / "History", Path(profile_dir) / "History"):
        if not hist.is_file():
            continue
        tmp = Path(tempfile.gettempdir()) / f"yt_hist_{abs(hash(str(hist)))}.db"
        try:
            _sh.copy2(hist, tmp)
            con = sqlite3.connect(str(tmp))
            try:
                rows = con.execute("SELECT target_path, end_time FROM downloads WHERE end_time > 0 ORDER BY end_time DESC LIMIT 60").fetchall()
            finally:
                con.close()
        except Exception:                                        # noqa: BLE001
            continue
        out = []
        for path, end in rows:
            try:
                if end / 1e6 - 11644473600 >= since_ts - 5 and Path(path).suffix.lower() not in (".crdownload", ".tmp"):
                    out.append(path)
            except Exception:                                    # noqa: BLE001
                continue
        return out
    return []


def _digest(p: Path) -> str:
    import hashlib
    try:
        h = hashlib.sha1()
        with open(p, "rb") as f:
            for chunk in iter(lambda: f.read(1 << 20), b""):
                h.update(chunk)
        return h.hexdigest()
    except OSError:
        return ""
